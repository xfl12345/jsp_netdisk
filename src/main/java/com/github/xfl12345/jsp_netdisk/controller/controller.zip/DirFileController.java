package pers.xfl.jsp_netdisk.controller;

import pers.xfl.jsp_netdisk.model.pojo.DirFile;
import pers.xfl.jsp_netdisk.service.DirFileService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * (DirFile)表控制层
 *
 * @author makejava
 * @since 2021-04-19 16:00:51
 */
@RestController
@RequestMapping("dirFile")
public class DirFileController {
    /**
     * 服务对象
     */
    @Resource
    private DirFileService dirFileService;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("selectOne")
    public DirFile selectOne(Long id) {
        return this.dirFileService.queryById(id);
    }

}
